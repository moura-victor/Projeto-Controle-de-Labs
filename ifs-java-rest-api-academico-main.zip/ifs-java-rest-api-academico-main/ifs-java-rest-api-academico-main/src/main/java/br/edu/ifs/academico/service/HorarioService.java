package br.edu.ifs.academico.service;

import br.edu.ifs.academico.model.HorarioModel;
import br.edu.ifs.academico.model.LaboratorioModel;
import br.edu.ifs.academico.model.PessoaModel;
import br.edu.ifs.academico.repository.HorarioRepository;
import br.edu.ifs.academico.repository.LaboratorioRepository;
import br.edu.ifs.academico.repository.PessoaRepository;
import br.edu.ifs.academico.rest.dto.HorarioDto;
import br.edu.ifs.academico.rest.form.HorarioForm;
import br.edu.ifs.academico.rest.form.HorarioUpdateForm;
import br.edu.ifs.academico.service.exceptions.DataIntegrityException;
import br.edu.ifs.academico.service.exceptions.ObjectNotFoundException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DataIntegrityViolationException;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;
import java.util.NoSuchElementException;
import java.util.Optional;

@Service
public class HorarioService {

    @Autowired
    HorarioRepository horarioRepository;
    @Autowired
    LaboratorioRepository laboratorioRepository;
    @Autowired
    PessoaRepository pessoaRepository;

    public HorarioDto findById(long idHorario) {
        try {
            HorarioModel horarioModel = horarioRepository.findById(idHorario).get();
            return convertHorarioModelToHorarioDto(horarioModel);
        } catch (NoSuchElementException e) {
            throw new ObjectNotFoundException("Objeto não encontrado! ID : " + idHorario + ", Tipo: " + HorarioModel.class.getName());
        }
    }

    public List<HorarioDto> findAll(){
        List<HorarioModel> horarioList = horarioRepository.findAll();
        return convertListToDto(horarioList);
    }

    public HorarioDto insert(HorarioForm horarioForm) {
        try {
            HorarioModel horarioNovo = convertHorarioFormToHorarioModel(horarioForm);
            horarioRepository.save(horarioNovo);
            return convertHorarioModelToHorarioDto(horarioNovo);
        } catch (DataIntegrityViolationException e) {
            throw new DataIntegrityException("Campo(s) obrigatório(s) do horario não foi(foram) preenchido(s).");
        }
    }

    public HorarioDto update(HorarioUpdateForm horarioUpdateForm, long idHorario) {
        try {
            Optional<HorarioModel> horarioExistente = horarioRepository.findById(idHorario);
            if (horarioExistente.isPresent()) {
                HorarioModel horarioAtualizado = horarioExistente.get();
                PessoaModel pessoaAtualizado = new PessoaModel();
                pessoaAtualizado.setIdPessoa(horarioUpdateForm.getIdPessoa());
                horarioAtualizado.setPessoaModel(pessoaAtualizado);

                LaboratorioModel laboratorioAtualizado = new LaboratorioModel();
                laboratorioAtualizado.setIdLaboratorio(horarioUpdateForm.getIdLaboratorio());
                horarioAtualizado.setLaboratorioModel(laboratorioAtualizado);
                horarioRepository.save(horarioAtualizado);
                return convertHorarioModelToHorarioDto(horarioAtualizado);
            }else{
                throw new DataIntegrityException("O ID do horário não existe na base de dados!");
            }
        } catch (DataIntegrityViolationException e) {
            throw new DataIntegrityException("Campo(s) obrigatório(s) do Horário não foi(foram) preenchido(s).");
        }
    }

    public void delete(long idHorario) {
        try {
            if (horarioRepository.existsById(idHorario)) {
                horarioRepository.deleteById(idHorario);
            }
        } catch (DataIntegrityViolationException e) {
            throw new DataIntegrityException("Não é possível excluir um Horário!");
        }
    }

    private HorarioModel convertHorarioFormToHorarioModel(HorarioForm horarioForm) {
        HorarioModel horarioModel = new HorarioModel();
        horarioModel.setDataHoraInicio(horarioForm.getDataHoraInicio());
        horarioModel.setDataHoraFim(horarioForm.getDataHoraFim());
        PessoaModel pessoaModel = new PessoaModel();
        pessoaModel.setIdPessoa(horarioForm.getIdPessoa());
        horarioModel.setPessoaModel(pessoaModel);
        LaboratorioModel laboratorioModel = new LaboratorioModel();
        laboratorioModel.setIdLaboratorio(horarioForm.getIdLaboratorio());
        horarioModel.setLaboratorioModel(laboratorioModel);
        return horarioModel;
    }

    private HorarioDto convertHorarioModelToHorarioDto(HorarioModel horarioModel) {
        HorarioDto horarioDto = new HorarioDto();
        horarioDto.setIdHorario(horarioModel.getIdHorario());
        horarioDto.setDataHoraInicio(horarioModel.getDataHoraInicio());
        horarioDto.setDataHoraFim(horarioModel.getDataHoraFim());
        Optional<PessoaModel> optionalPessoaModel = pessoaRepository.findById(horarioModel.getPessoaModel().getIdPessoa());
        horarioDto.setIdPessoa(optionalPessoaModel.get().getIdPessoa());
        Optional<LaboratorioModel> optionalLaboratorioModel = laboratorioRepository.findById(horarioModel.getLaboratorioModel().getIdLaboratorio());
        horarioDto.setIdLaboratorio(optionalLaboratorioModel.get().getIdLaboratorio());
        return horarioDto;
    }

    private List<HorarioDto> convertListToDto(List<HorarioModel> list){
        List<HorarioDto> horarioDtoList = new ArrayList<>();
        for (HorarioModel horarioModel : list) {
            HorarioDto horarioDto = this.convertHorarioModelToHorarioDto(horarioModel);
            horarioDtoList.add(horarioDto);
        }
        return horarioDtoList;
    }

}
