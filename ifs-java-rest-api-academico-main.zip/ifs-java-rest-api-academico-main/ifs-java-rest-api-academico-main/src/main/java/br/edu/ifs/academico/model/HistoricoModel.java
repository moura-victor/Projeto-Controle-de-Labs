package br.edu.ifs.academico.model;

import lombok.Data;

import javax.persistence.*;
import java.time.LocalDateTime;

@Entity
@Data
@Table(name = "TB_HISTORICO")
public class HistoricoModel {

    @Id @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long idHistorico;

    @Column(name = "DataHora", nullable = false)
    private LocalDateTime dataHora;

    @ManyToOne
    @JoinColumn(name = "idHorario", referencedColumnName = "idHorario")
    private HorarioModel horarioModel;



}
