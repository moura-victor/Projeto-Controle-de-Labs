package br.edu.ifs.academico.repository;

import br.edu.ifs.academico.model.HorarioModel;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Optional;

@Repository
public interface HorarioRepository extends JpaRepository<HorarioModel, Long> {




    Optional<HorarioModel> findById(Long idHorario);

}
