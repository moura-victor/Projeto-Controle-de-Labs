package br.edu.ifs.academico.rest.controller;

import br.edu.ifs.academico.rest.dto.HorarioDto;
import br.edu.ifs.academico.rest.form.HorarioForm;
import br.edu.ifs.academico.rest.form.HorarioUpdateForm;
import br.edu.ifs.academico.service.HorarioService;
import br.edu.ifs.academico.service.exceptions.ConstraintException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.*;

import javax.validation.Valid;
import java.util.List;

@RestController
@RequestMapping("/horario")
public class HorarioController {

    @Autowired
    private HorarioService horarioService;

    @GetMapping
    public ResponseEntity<List<HorarioDto>> findAll() {
        List<HorarioDto> horarioDtoList = horarioService.findAll();
        return ResponseEntity.ok().body(horarioDtoList);
    }

    @GetMapping("/{id}")
    public ResponseEntity<HorarioDto> find(@PathVariable("id") long idHorario) {
        HorarioDto horarioDto = horarioService.findById(idHorario);
        return ResponseEntity.ok().body(horarioDto);
    }

    @PostMapping
    public ResponseEntity<HorarioDto> insert(@Valid @RequestBody HorarioForm horarioForm, BindingResult br) {
        if (br.hasErrors())
            throw new ConstraintException(br.getAllErrors().get(0).getDefaultMessage());

        HorarioDto horarioDto = horarioService.insert(horarioForm);
        return ResponseEntity.ok().body(horarioDto);
    }

    @PutMapping("/{id}")
    public ResponseEntity<HorarioDto> update(@Valid @RequestBody HorarioUpdateForm horarioUpdateForm
            , @PathVariable("id") long idHorario, BindingResult br) {
        if (br.hasErrors())
            throw new ConstraintException(br.getAllErrors().get(0).getDefaultMessage());

        HorarioDto horarioDto = horarioService.update(horarioUpdateForm, idHorario );
        return ResponseEntity.ok().body(horarioDto);
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<Void> delete(@PathVariable("id") long idHorario) {
        horarioService.delete(idHorario);
        return ResponseEntity.noContent().build();
    }
}
