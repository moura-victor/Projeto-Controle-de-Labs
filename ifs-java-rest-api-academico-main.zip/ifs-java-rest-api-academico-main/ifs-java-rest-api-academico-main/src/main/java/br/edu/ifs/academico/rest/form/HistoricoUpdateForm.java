package br.edu.ifs.academico.rest.form;

import lombok.Data;

import javax.validation.constraints.NotNull;

@Data
public class HistoricoUpdateForm {

    @NotNull(message = "O id de horário não pode estar em branco!")
    private Long idHorario;

}
