package br.edu.ifs.academico.service;

import br.edu.ifs.academico.model.DepartamentoModel;
import br.edu.ifs.academico.repository.DepartamentoRepository;
import br.edu.ifs.academico.rest.dto.DepartamentoDto;
import br.edu.ifs.academico.rest.form.DepartamentoForm;
import br.edu.ifs.academico.rest.form.DepartamentoUpdateForm;
import br.edu.ifs.academico.service.exceptions.DataIntegrityException;
import br.edu.ifs.academico.service.exceptions.ObjectNotFoundException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DataIntegrityViolationException;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;
import java.util.NoSuchElementException;
import java.util.Optional;

@Service
public class DepartamentoService {

    @Autowired
    DepartamentoRepository departamentoRepository;


    public DepartamentoDto findById(long idDepartamento) {
        try {
            DepartamentoModel departamentoModel = departamentoRepository.findById(idDepartamento).get();
            return convertDepartamentoModelToDepartamentoDto(departamentoModel);
        } catch (NoSuchElementException e) {
            throw new ObjectNotFoundException("Objeto não encontrado! ID : " + idDepartamento + ", Tipo: " + DepartamentoModel.class.getName());
        }
    }

    public List<DepartamentoDto> findAll(){
        List<DepartamentoModel> departamentoList = departamentoRepository.findAll();
        return convertListToDto(departamentoList);
    }

    public DepartamentoDto insert(DepartamentoForm departamentoForm) {
        try {
            DepartamentoModel departamentoNovo = convertDepartamentoFormToDepartamentoModel(departamentoForm);
            Optional<DepartamentoModel> byNome = departamentoRepository.findByNome(departamentoNovo.getNome());
            if (byNome.isPresent()) {
                throw new IllegalStateException("Nome já registrado.");
            }
            departamentoRepository.save(departamentoNovo);
            return convertDepartamentoModelToDepartamentoDto(departamentoNovo);
        } catch (DataIntegrityViolationException e) {
            throw new DataIntegrityException("Campo(s) obrigatório(s) do Departamento não foi(foram) preenchido(s).");
        }
    }

    public DepartamentoDto update(DepartamentoUpdateForm departamentoUpdateForm, long idDepartamento) {
        try {
            Optional<DepartamentoModel> departamentoExistente = departamentoRepository.findById(idDepartamento);
            if (departamentoExistente.isPresent()) {
                DepartamentoModel departamentoAtualizado = departamentoExistente.get();
                departamentoAtualizado.setNome(departamentoUpdateForm.getNome());
                departamentoAtualizado.setDescricao(departamentoUpdateForm.getDescricao());
                return convertDepartamentoModelToDepartamentoDto(departamentoAtualizado);
            }else{
                throw new DataIntegrityException("O ID do Departamento não existe na base de dados!");
            }
        } catch (DataIntegrityViolationException e) {
            throw new DataIntegrityException("Campo(s) obrigatório(s) do Departamento não foi(foram) preenchido(s).");
        }
    }

    public void delete(long idDepartamento) {
        try {
            if (departamentoRepository.existsById(idDepartamento)) {
                departamentoRepository.deleteById(idDepartamento);
            }
        } catch (DataIntegrityViolationException e) {
            throw new DataIntegrityException("Não é possível excluir um Departamento!");
        }
    }

    private DepartamentoModel convertDepartamentoFormToDepartamentoModel(DepartamentoForm departamentoForm) {
        DepartamentoModel departamentoModel = new DepartamentoModel();
        departamentoModel.setNome(departamentoForm.getNome());
        departamentoModel.setDescricao(departamentoForm.getDescricao());
        return departamentoModel;
    }

    private DepartamentoDto convertDepartamentoModelToDepartamentoDto(DepartamentoModel departamentoModel) {
        DepartamentoDto departamentoDto = new DepartamentoDto();
        departamentoDto.setIdDepartamento(departamentoModel.getIdDepartamento());
        departamentoDto.setNome(departamentoModel.getNome());
        departamentoDto.setDescricao(departamentoModel.getDescricao());
        return departamentoDto;
    }

    private List<DepartamentoDto> convertListToDto(List<DepartamentoModel> list){
        List<DepartamentoDto> departamentoDtoList = new ArrayList<>();
        for (DepartamentoModel departamentoModel : list) {
            DepartamentoDto departamentoDto = this.convertDepartamentoModelToDepartamentoDto(departamentoModel);
            departamentoDtoList.add(departamentoDto);
        }
        return departamentoDtoList;
    }
}

