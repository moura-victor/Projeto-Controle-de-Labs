package br.edu.ifs.academico.rest.dto;


import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDateTime;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class HorarioDto {

    private Long idHorario;

    private LocalDateTime dataHoraInicio;

    private LocalDateTime dataHoraFim;

    private Long idPessoa;

    private Long idLaboratorio;

}
