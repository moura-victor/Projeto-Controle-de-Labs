package br.edu.ifs.academico.rest.controller;

import br.edu.ifs.academico.rest.dto.LaboratorioDto;
import br.edu.ifs.academico.rest.form.LaboratorioForm;
import br.edu.ifs.academico.rest.form.LaboratorioUpdateForm;
import br.edu.ifs.academico.service.LaboratorioService;
import br.edu.ifs.academico.service.exceptions.ConstraintException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.*;

import javax.validation.Valid;
import java.util.List;

@RestController
@RequestMapping("/laboratorio")
public class LaboratorioController {
    @Autowired
    private LaboratorioService laboratorioService;

    @GetMapping
    public ResponseEntity<List<LaboratorioDto>> findAll() {
        List<LaboratorioDto> laboratorioDtoList = laboratorioService.findAll();
        return ResponseEntity.ok().body(laboratorioDtoList);
    }

    @GetMapping("/{id}")
    public ResponseEntity<LaboratorioDto> find(@PathVariable("id") long idLaboratorio) {
        LaboratorioDto laboratorioDto = laboratorioService.findById(idLaboratorio);
        return ResponseEntity.ok().body(laboratorioDto);
    }

    @PostMapping
    public ResponseEntity<LaboratorioDto> insert(@Valid @RequestBody LaboratorioForm laboratorioForm, BindingResult br) {
        if (br.hasErrors())
            throw new ConstraintException(br.getAllErrors().get(0).getDefaultMessage());

        LaboratorioDto laboratorioDto = laboratorioService.insert(laboratorioForm);
        return ResponseEntity.ok().body(laboratorioDto);
    }

    @PutMapping("/{id}")
    public ResponseEntity<LaboratorioDto> update(@Valid @RequestBody LaboratorioUpdateForm laboratorioUpdateForm
            , @PathVariable("id") long idLaboratorio, BindingResult br) {
        if (br.hasErrors())
            throw new ConstraintException(br.getAllErrors().get(0).getDefaultMessage());

        LaboratorioDto laboratorioDto = laboratorioService.update(laboratorioUpdateForm, idLaboratorio );
        return ResponseEntity.ok().body(laboratorioDto);
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<Void> delete(@PathVariable("id") long idLaboratorio) {
        laboratorioService.delete(idLaboratorio);
        return ResponseEntity.noContent().build();
    }





}
