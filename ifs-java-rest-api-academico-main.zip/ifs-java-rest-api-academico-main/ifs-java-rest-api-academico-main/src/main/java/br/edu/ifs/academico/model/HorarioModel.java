package br.edu.ifs.academico.model;

import lombok.Data;

import javax.persistence.*;
import java.time.LocalDateTime;

@Entity
@Data
@Table(name ="TB_HORARIO")
public class HorarioModel {

    @Id @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long idHorario;

    @Column(name = "dataHoraInicio", nullable = false)
    private LocalDateTime dataHoraInicio;

    @Column(name = "dataHoraFim", nullable = false)
    private LocalDateTime dataHoraFim;

    @ManyToOne
    @JoinColumn(name = "idPessoa", referencedColumnName = "idPessoa")
    private PessoaModel pessoaModel;

    @ManyToOne
    @JoinColumn(name = "idLaboratorio", referencedColumnName = "idLaboratorio")
    private LaboratorioModel laboratorioModel;



}
