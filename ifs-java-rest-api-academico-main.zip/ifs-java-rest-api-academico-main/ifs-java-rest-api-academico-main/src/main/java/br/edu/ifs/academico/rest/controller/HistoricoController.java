package br.edu.ifs.academico.rest.controller;

import br.edu.ifs.academico.rest.dto.HistoricoDto;
import br.edu.ifs.academico.rest.form.HistoricoForm;
import br.edu.ifs.academico.rest.form.HistoricoUpdateForm;
import br.edu.ifs.academico.service.HistoricoService;
import br.edu.ifs.academico.service.exceptions.ConstraintException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.*;

import javax.validation.Valid;
import java.util.List;

@RestController
@RequestMapping("/historico")
public class HistoricoController {

    @Autowired
    private HistoricoService historicoService;

    @GetMapping
    public ResponseEntity<List<HistoricoDto>> findAll() {
        List<HistoricoDto> historicoDtoList = historicoService.findAll();
        return ResponseEntity.ok().body(historicoDtoList);
    }

    @GetMapping("/{id}")
    public ResponseEntity<HistoricoDto> find(@PathVariable("id") long idHistorico) {
        HistoricoDto historicoDto = historicoService.findById(idHistorico);
        return ResponseEntity.ok().body(historicoDto);
    }

    @PostMapping
    public ResponseEntity<HistoricoDto> insert(@Valid @RequestBody HistoricoForm historicoForm, BindingResult br) {
        if (br.hasErrors())
            throw new ConstraintException(br.getAllErrors().get(0).getDefaultMessage());

        HistoricoDto historicoDto = historicoService.insert(historicoForm);
        return ResponseEntity.ok().body(historicoDto);
    }

    @PutMapping("/{id}")
    public ResponseEntity<HistoricoDto> update(@Valid @RequestBody HistoricoUpdateForm historicoUpdateForm
            , @PathVariable("id") long idHistorico, BindingResult br) {
        if (br.hasErrors())
            throw new ConstraintException(br.getAllErrors().get(0).getDefaultMessage());

        HistoricoDto historicoDto = historicoService.update(historicoUpdateForm, idHistorico );
        return ResponseEntity.ok().body(historicoDto);
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<Void> delete(@PathVariable("id") long idHistorico) {
        historicoService.delete(idHistorico);
        return ResponseEntity.noContent().build();
    }
}
