package br.edu.ifs.academico.repository;

import br.edu.ifs.academico.model.HistoricoModel;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.Optional;

@Repository
public interface HistoricoRepository extends JpaRepository<HistoricoModel, Long> {

    Optional<HistoricoModel> findById(Long idHistorico);


}
