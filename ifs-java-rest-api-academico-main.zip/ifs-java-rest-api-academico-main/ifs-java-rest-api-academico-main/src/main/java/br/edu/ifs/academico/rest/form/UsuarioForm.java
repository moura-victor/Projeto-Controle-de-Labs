package br.edu.ifs.academico.rest.form;

import lombok.Data;
import javax.validation.constraints.*;

@Data
public class UsuarioForm {

    @NotEmpty //Por que não aceita mensagem por aqui?
    @NotBlank(message = "O campo matrícula não pode estar em branco.")
    @Size(max = 64)
    private String matricula;

    @NotEmpty
    @NotBlank(message = "O campo senha não pode estar em branco")
    @Size(max = 512)
    private String senha;

    @NotNull
    private boolean ativo;

    @NotNull
    private boolean admin;
}
