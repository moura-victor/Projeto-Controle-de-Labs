package br.edu.ifs.academico.repository;


import br.edu.ifs.academico.model.DepartamentoModel;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Optional;

@Repository
public interface DepartamentoRepository extends JpaRepository<DepartamentoModel, Long> {

    
    List<DepartamentoModel> findByNomeContaining(String nome);
    
    List<DepartamentoModel> findByOrderByNomeDesc();
    
    Optional<DepartamentoModel> findById(Long idDepartamento);

    Optional<DepartamentoModel> findByNome(String nome);
    

}
