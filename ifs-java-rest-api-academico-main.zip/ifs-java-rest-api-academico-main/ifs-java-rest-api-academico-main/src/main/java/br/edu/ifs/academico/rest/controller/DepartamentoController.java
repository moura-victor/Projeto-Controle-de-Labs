package br.edu.ifs.academico.rest.controller;

import br.edu.ifs.academico.rest.dto.DepartamentoDto;
import br.edu.ifs.academico.rest.form.DepartamentoForm;
import br.edu.ifs.academico.rest.form.DepartamentoUpdateForm;
import br.edu.ifs.academico.service.DepartamentoService;
import br.edu.ifs.academico.service.exceptions.ConstraintException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.*;

import javax.validation.Valid;
import java.util.List;

@RestController
@RequestMapping("/departamento")
public class DepartamentoController {

    @Autowired
    private DepartamentoService departamentoService;

    @GetMapping
    public ResponseEntity<List<DepartamentoDto>> findAll() {
        List<DepartamentoDto> departamentoDtoList = departamentoService.findAll();
        return ResponseEntity.ok().body(departamentoDtoList);
    }

    @GetMapping("/{id}")
    public ResponseEntity<DepartamentoDto> find(@PathVariable("id") long idDepartamento) {
        DepartamentoDto departamentoDto = departamentoService.findById(idDepartamento);
        return ResponseEntity.ok().body(departamentoDto);
    }

    @PostMapping
    public ResponseEntity<DepartamentoDto> insert(@Valid @RequestBody DepartamentoForm departamentoForm, BindingResult br) {
        if (br.hasErrors())
            throw new ConstraintException(br.getAllErrors().get(0).getDefaultMessage());

        DepartamentoDto departamentoDto = departamentoService.insert(departamentoForm);
        return ResponseEntity.ok().body(departamentoDto);
    }

    @PutMapping("/{id}")
    public ResponseEntity<DepartamentoDto> update(@Valid @RequestBody DepartamentoUpdateForm departamentoUpdateForm
            , @PathVariable("id") long idDepartamento, BindingResult br) {
        if (br.hasErrors())
            throw new ConstraintException(br.getAllErrors().get(0).getDefaultMessage());

        DepartamentoDto departamentoDto = departamentoService.update(departamentoUpdateForm, idDepartamento );
        return ResponseEntity.ok().body(departamentoDto);
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<Void> delete(@PathVariable("id") long idDepartamento) {
        departamentoService.delete(idDepartamento);
        return ResponseEntity.noContent().build();
    }
}

