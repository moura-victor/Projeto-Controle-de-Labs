package br.edu.ifs.academico.rest.form;

import lombok.Data;

import javax.validation.constraints.NotNull;
import java.time.LocalDateTime;

@Data
public class HistoricoForm {

    @NotNull
    private LocalDateTime dataHora = LocalDateTime.now();

    @NotNull(message = "O id do horário não pode estar vazio!!!!!!")
    private Long idHorario;
}
