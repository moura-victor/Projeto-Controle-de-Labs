package br.edu.ifs.academico.rest.form;

import lombok.Data;

import javax.validation.constraints.*;
@Data
public class UsuarioUpdateForm {

    @NotNull(message = "O campo ID do usuário não pode ser nulo")
    private Long IdUsuario;

    @NotEmpty
    @NotBlank(message = "O campo matrícula não pode estar em branco.")
    @Size(max = 64)
    private String matricula;

    @NotEmpty
    @NotBlank(message = "O campo senha não pode estar em branco")
    @Size(max = 512)
    private String senha;

    @NotNull(message = "O campo ativo não pode ser nulo")
    private boolean ativo;

    @NotNull(message = "O campo administrador não pode ser nulo")
    private boolean admin;

}
