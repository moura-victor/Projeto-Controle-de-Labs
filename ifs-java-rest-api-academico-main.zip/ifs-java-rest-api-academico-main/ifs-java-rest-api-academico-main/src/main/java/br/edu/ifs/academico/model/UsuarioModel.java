package br.edu.ifs.academico.model;

import lombok.Data;

import javax.persistence.*;

@Data
@Entity
@Table(name="TB_USUARIO")
public class UsuarioModel {

    @Id @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long idUsuario;

    @Column (name = "matricula", length = 64, nullable = false, unique = true)
    private String matricula;

    @Column (name = "senha", length = 512, nullable = false)
    private String senha;

    @Column (name = "ativo", nullable = false)
    private boolean ativo;

    @Column (name = "admin", nullable = false)
    private boolean admin;

    @OneToOne
    @JoinColumn(name = "idPessoa", referencedColumnName = "idPessoa")
    private PessoaModel pessoaModel;


}
