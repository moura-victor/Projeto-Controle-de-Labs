package br.edu.ifs.academico.rest.form;

import lombok.Data;

import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotEmpty;
import javax.validation.constraints.Size;

@Data
public class LaboratorioForm {

    @NotEmpty
    @NotBlank(message = "O nome não pode estar em branco! ")
    @Size(max = 64)
    private String nome;

    @Size(max = 256)
    private String descricao;

    private Long idDepartamento;


}
