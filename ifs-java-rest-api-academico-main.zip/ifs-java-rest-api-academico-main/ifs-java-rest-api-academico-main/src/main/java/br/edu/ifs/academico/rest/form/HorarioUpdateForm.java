package br.edu.ifs.academico.rest.form;

import lombok.Data;

import javax.validation.constraints.NotNull;

@Data
public class HorarioUpdateForm {

    @NotNull(message = "O Id da pessoa não pode estar em branco!")
    private Long idPessoa;

    @NotNull(message = "O Id do laboratório não pode estar em branco!")
    private Long idLaboratorio;
}
