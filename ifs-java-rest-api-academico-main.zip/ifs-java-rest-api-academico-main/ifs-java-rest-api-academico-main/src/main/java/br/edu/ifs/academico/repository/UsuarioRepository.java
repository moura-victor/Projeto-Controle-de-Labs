package br.edu.ifs.academico.repository;

import br.edu.ifs.academico.model.UsuarioModel;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Optional;

@Repository
public interface UsuarioRepository extends JpaRepository<UsuarioModel, Long> {


    Optional<UsuarioModel> findById(Long id); //Is finById really needed? It already overrides something

    Optional<UsuarioModel> findByMatricula(String matricula);

    List<UsuarioModel> findByOrderByMatriculaAsc();

    List<UsuarioModel> findAllByAdminIsTrue();

    List<UsuarioModel> findAllByAdminIsFalse();

    List<UsuarioModel> findAllByAtivoIsTrue();


}
