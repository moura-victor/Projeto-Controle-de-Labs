package br.edu.ifs.academico.rest.form;

import lombok.Data;

import javax.validation.constraints.NotNull;
import java.time.LocalDateTime;

@Data
public class HorarioForm {
    @NotNull
    private LocalDateTime dataHoraInicio = LocalDateTime.now();

    @NotNull
    private LocalDateTime dataHoraFim = LocalDateTime.now();

    @NotNull(message = "O id da pessoa não pode estar vazio!")
    private Long idPessoa;

    @NotNull(message = "O id do laboratório não pode estar vazio!")
    private Long idLaboratorio;


}
