package br.edu.ifs.academico.service;

import br.edu.ifs.academico.model.DepartamentoModel;
import br.edu.ifs.academico.model.LaboratorioModel;
import br.edu.ifs.academico.repository.DepartamentoRepository;
import br.edu.ifs.academico.repository.LaboratorioRepository;
import br.edu.ifs.academico.rest.dto.LaboratorioDto;
import br.edu.ifs.academico.rest.form.LaboratorioForm;
import br.edu.ifs.academico.rest.form.LaboratorioUpdateForm;
import br.edu.ifs.academico.service.exceptions.DataIntegrityException;
import br.edu.ifs.academico.service.exceptions.ObjectNotFoundException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DataIntegrityViolationException;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;
import java.util.NoSuchElementException;
import java.util.Optional;

@Service
public class LaboratorioService {

    @Autowired
    LaboratorioRepository laboratorioRepository;
    @Autowired
    DepartamentoRepository departamentoRepository;


    public LaboratorioDto findById(long idLaboratorio) {
        try {
            LaboratorioModel laboratorioModel = laboratorioRepository.findById(idLaboratorio).get();
            return convertLaboratorioModelToLaboratorioDto(laboratorioModel);
        } catch (NoSuchElementException e) {
            throw new ObjectNotFoundException("Objeto não encontrado! Id Laboratório: " + idLaboratorio + ", Tipo: " + LaboratorioModel.class.getName());
        }
    }

    public List<LaboratorioDto> findAll(){
        List<LaboratorioModel> laboratorioList = laboratorioRepository.findAll();
        return convertListToDto(laboratorioList);
    }

    public LaboratorioDto insert(LaboratorioForm laboratorioForm) {
        try {
            LaboratorioModel laboratorioNovo = convertLaboratorioFormToLaboratorioModel(laboratorioForm);
            Optional<LaboratorioModel> byNome = laboratorioRepository.findByNome(laboratorioNovo.getNome());
            if (byNome.isPresent()) {
                throw new IllegalStateException("Nome já registrado.");
            }
            laboratorioNovo = laboratorioRepository.save(laboratorioNovo);
            return convertLaboratorioModelToLaboratorioDto(laboratorioNovo);
        } catch (DataIntegrityViolationException e) {
            throw new DataIntegrityException("Campo(s) obrigatório(s) do Laboratório não foi(foram) preenchido(s).");
        }
    }

    public LaboratorioDto update(LaboratorioUpdateForm laboratorioUpdateForm, long idLaboratorio) {
        try {
            Optional<LaboratorioModel> laboratorioExistente = laboratorioRepository.findById(idLaboratorio);
            if (laboratorioExistente.isPresent()) {
                LaboratorioModel laboratorioAtualizado = laboratorioExistente.get();
                laboratorioAtualizado.setNome(laboratorioUpdateForm.getNome());
                laboratorioAtualizado.setDescricao(laboratorioUpdateForm.getDescricao());
                DepartamentoModel departamentoAtualizado = new DepartamentoModel();
                departamentoAtualizado.setIdDepartamento(laboratorioUpdateForm.getIdDepartamento());
                laboratorioAtualizado.setDepartamentoModel(departamentoAtualizado);
                laboratorioRepository.save(laboratorioAtualizado);
                return convertLaboratorioModelToLaboratorioDto(laboratorioAtualizado);
            }else{
                throw new DataIntegrityException("O Id do Laboratório não existe na base de dados!");
            }
        } catch (DataIntegrityViolationException e) {
            throw new DataIntegrityException("Campo(s) obrigatório(s) do Laboratório não foi(foram) preenchido(s).");
        }
    }

    public void delete(long idLaboratorio) {
        try {
            if (laboratorioRepository.existsById(idLaboratorio)) {
                laboratorioRepository.deleteById(idLaboratorio);
            }
        } catch (DataIntegrityViolationException e) {
            throw new DataIntegrityException("Não é possível excluir um Laboratório!");
        }
    }

    private LaboratorioModel convertLaboratorioFormToLaboratorioModel(LaboratorioForm laboratorioForm) {
        LaboratorioModel laboratorioModel = new LaboratorioModel();
        laboratorioModel.setNome(laboratorioForm.getNome());
        laboratorioModel.setDescricao(laboratorioForm.getDescricao());
        DepartamentoModel departamentoModel = new DepartamentoModel();
        departamentoModel.setIdDepartamento(laboratorioForm.getIdDepartamento());
        laboratorioModel.setDepartamentoModel(departamentoModel);
        return laboratorioModel;
    }

    private LaboratorioDto convertLaboratorioModelToLaboratorioDto(LaboratorioModel laboratorioModel) {
        LaboratorioDto laboratorioDto = new LaboratorioDto();
        laboratorioDto.setIdLaboratorio(laboratorioModel.getIdLaboratorio());
        laboratorioDto.setNome(laboratorioModel.getNome());
        laboratorioDto.setDescricao(laboratorioDto.getDescricao());
        Optional<DepartamentoModel> optionalDepartamentoModel = departamentoRepository.findById(laboratorioModel.getDepartamentoModel().getIdDepartamento());
        laboratorioDto.setIdDepartamento(optionalDepartamentoModel.get().getIdDepartamento());
        return laboratorioDto;
    }

    private List<LaboratorioDto> convertListToDto(List<LaboratorioModel> list){
        List<LaboratorioDto> laboratorioDtoList = new ArrayList<>();
        for (LaboratorioModel laboratorioModel : list) {
            LaboratorioDto laboratorioDto = this.convertLaboratorioModelToLaboratorioDto(laboratorioModel);
            laboratorioDtoList.add(laboratorioDto);
        }
        return laboratorioDtoList;
    }

}
