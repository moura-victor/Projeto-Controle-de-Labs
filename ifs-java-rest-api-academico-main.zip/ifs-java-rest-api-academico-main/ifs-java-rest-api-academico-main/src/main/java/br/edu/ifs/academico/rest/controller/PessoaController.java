package br.edu.ifs.academico.rest.controller;

import br.edu.ifs.academico.rest.dto.PessoaDto;
import br.edu.ifs.academico.rest.form.PessoaForm;
import br.edu.ifs.academico.rest.form.PessoaUpdateForm;
import br.edu.ifs.academico.service.PessoaService;
import br.edu.ifs.academico.service.exceptions.ConstraintException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.*;

import javax.validation.Valid;
import java.util.List;

@RestController
@RequestMapping("/pessoa")
public class PessoaController {

    @Autowired
    private PessoaService pessoaService;

    @GetMapping
    public ResponseEntity<List<PessoaDto>> findAll() {
        List<PessoaDto> pessoaDtoList = pessoaService.findAll();
        return ResponseEntity.ok().body(pessoaDtoList);
    }

    @GetMapping("/{id}")
    public ResponseEntity<PessoaDto> find(@PathVariable("id") long idPessoa) {
        PessoaDto pessoaDto = pessoaService.findById(idPessoa);
        return ResponseEntity.ok().body(pessoaDto);
    }

    @PostMapping
    public ResponseEntity<PessoaDto> insert(@Valid @RequestBody PessoaForm pessoaForm, BindingResult br) {
        if (br.hasErrors())
            throw new ConstraintException(br.getAllErrors().get(0).getDefaultMessage());

        PessoaDto pessoaDto = pessoaService.insert(pessoaForm);
        return ResponseEntity.ok().body(pessoaDto);
    }

    @PutMapping("/{id}")
    public ResponseEntity<PessoaDto> update(@Valid @RequestBody PessoaUpdateForm pessoaUpdateForm
            , @PathVariable("id") long idPessoa, BindingResult br) {
        if (br.hasErrors())
            throw new ConstraintException(br.getAllErrors().get(0).getDefaultMessage());

        PessoaDto pessoaDto = pessoaService.update(pessoaUpdateForm, idPessoa);
        return ResponseEntity.ok().body(pessoaDto);
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<Void> delete(@PathVariable("id") long idPessoa) {
        pessoaService.delete(idPessoa);
        return ResponseEntity.noContent().build();
    }
}
