package br.edu.ifs.academico.repository;

import br.edu.ifs.academico.model.LaboratorioModel;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Optional;

@Repository
public interface LaboratorioRepository extends JpaRepository<LaboratorioModel, Long> {

    Optional<LaboratorioModel> findById(Long idLaboratorio);

    Optional<LaboratorioModel> findByNome(String nome);

    List<LaboratorioModel> findByNomeContaining(String nome);

    List<LaboratorioModel> findByOrderByNomeDesc();



}
