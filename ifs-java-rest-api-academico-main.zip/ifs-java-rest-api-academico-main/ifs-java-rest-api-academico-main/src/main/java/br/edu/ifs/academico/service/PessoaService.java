package br.edu.ifs.academico.service;

import br.edu.ifs.academico.repository.PessoaRepository;
import br.edu.ifs.academico.rest.dto.PessoaDto;
import br.edu.ifs.academico.rest.form.PessoaForm;
import br.edu.ifs.academico.rest.form.PessoaUpdateForm;
import br.edu.ifs.academico.model.PessoaModel;
import br.edu.ifs.academico.service.exceptions.DataIntegrityException;
import br.edu.ifs.academico.service.exceptions.ObjectNotFoundException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DataIntegrityViolationException;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;
import java.util.NoSuchElementException;
import java.util.Optional;

@Service
public class PessoaService {

    @Autowired
    PessoaRepository pessoaRepository;

    public PessoaDto findById(long idPessoa) {
        try {
            PessoaModel pessoaModel = pessoaRepository.findById(idPessoa).get();
            return convertPessoaModelToPessoaDto(pessoaModel);
        } catch (NoSuchElementException e) {
            throw new ObjectNotFoundException("Objeto não encontrado! Matrícula: " + idPessoa + ", Tipo: " + PessoaModel.class.getName());
        }
    }

    public List<PessoaDto> findAll(){
        List<PessoaModel> pessoaList = pessoaRepository.findAll();
        return convertListToDto(pessoaList);
    }

    public PessoaDto insert(PessoaForm pessoaForm) {
        try {
            PessoaModel pessoaNovo = convertPessoaFormToPessoaModel(pessoaForm);
            Optional<PessoaModel> byCpf = pessoaRepository.findByCpf(pessoaNovo.getCpf());
            if (byCpf.isPresent()) {
                throw new IllegalStateException("CPF já registrado.");
            }
            pessoaRepository.save(pessoaNovo);
            return convertPessoaModelToPessoaDto(pessoaNovo);
        } catch (DataIntegrityViolationException e) {
            throw new DataIntegrityException("Campo(s) obrigatório(s) do Aluno não foi(foram) preenchido(s).");
        }
    }

    public PessoaDto update(PessoaUpdateForm pessoaUpdateForm, long idPessoa) {
        try {
            Optional<PessoaModel> pessoaExistente = pessoaRepository.findById(idPessoa);
            if (pessoaExistente.isPresent()) {
                PessoaModel pessoaAtualizado = pessoaExistente.get();
                pessoaAtualizado.setNome(pessoaUpdateForm.getNome());
                pessoaAtualizado.setSexo(pessoaUpdateForm.getSexo());
                pessoaRepository.save(pessoaAtualizado);
                return convertPessoaModelToPessoaDto(pessoaAtualizado);
            }else{
                throw new DataIntegrityException("O ID de Pessoa não existe na base de dados!");
            }
        } catch (DataIntegrityViolationException e) {
            throw new DataIntegrityException("Campo(s) obrigatório(s) do Aluno não foi(foram) preenchido(s).");
        }
    }

    public void delete(long idPessoa) {
        try {
            if (pessoaRepository.existsById(idPessoa)) {
                pessoaRepository.deleteById(idPessoa);
            }
        } catch (DataIntegrityViolationException e) {
            throw new DataIntegrityException("Não é possível excluir uma Pessoa!");
        }
    }

    private PessoaModel convertPessoaFormToPessoaModel(PessoaForm pessoaForm) {
        PessoaModel pessoaModel = new PessoaModel();
        pessoaModel.setNome(pessoaForm.getNome());
        pessoaModel.setCpf(pessoaForm.getCpf());
        pessoaModel.setSexo(pessoaForm.getSexo());
        pessoaModel.setDataNascimento(pessoaForm.getDataNascimento());
        return pessoaModel;
    }

    private PessoaDto convertPessoaModelToPessoaDto(PessoaModel pessoaModel) {
        PessoaDto pessoaDto = new PessoaDto();
        pessoaDto.setIdPessoa(pessoaModel.getIdPessoa());
        pessoaDto.setNome(pessoaModel.getNome());
        return pessoaDto;
    }

    private List<PessoaDto> convertListToDto(List<PessoaModel> list){
        List<PessoaDto> pessoaDtoList = new ArrayList<>();
        for (PessoaModel pessoaModel : list) {
            PessoaDto pessoaDto = this.convertPessoaModelToPessoaDto(pessoaModel);
            pessoaDtoList.add(pessoaDto);
        }
        return pessoaDtoList;
    }
}
