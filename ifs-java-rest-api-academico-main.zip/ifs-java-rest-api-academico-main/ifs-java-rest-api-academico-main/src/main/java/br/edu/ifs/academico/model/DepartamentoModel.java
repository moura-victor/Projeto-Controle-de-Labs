package br.edu.ifs.academico.model;

import lombok.Data;
import javax.persistence.*;

@Entity
@Data
@Table(name="TB_DEPARTAMENTO")
public class DepartamentoModel {

    @Id @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long idDepartamento;

    @Column(name = "nome", length = 128, nullable = false)
    private String nome;

    @Column(name = "descricao", length = 256, nullable = false)
    private String descricao;




}
