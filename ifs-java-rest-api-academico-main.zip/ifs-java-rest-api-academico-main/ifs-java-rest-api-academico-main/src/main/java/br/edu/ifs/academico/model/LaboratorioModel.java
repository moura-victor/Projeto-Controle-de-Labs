package br.edu.ifs.academico.model;

import lombok.Data;

import javax.persistence.*;

@Data
@Entity
@Table(name = "TB_LABORATORIOS")
public class LaboratorioModel {

    @Id @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long idLaboratorio;

    @Column(name = "nome", length = 64, nullable = false)
    private String nome;

    @Column(name = "descricao", length = 256, nullable = false)
    private String descricao;

    @ManyToOne
    @JoinColumn(name = "idDepartamento", referencedColumnName = "idDepartamento")
    private DepartamentoModel departamentoModel;



}
