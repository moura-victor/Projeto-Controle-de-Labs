package br.edu.ifs.academico.service;

import br.edu.ifs.academico.model.HistoricoModel;
import br.edu.ifs.academico.model.HorarioModel;
import br.edu.ifs.academico.repository.HistoricoRepository;
import br.edu.ifs.academico.repository.HorarioRepository;
import br.edu.ifs.academico.rest.dto.HistoricoDto;
import br.edu.ifs.academico.rest.form.HistoricoForm;
import br.edu.ifs.academico.rest.form.HistoricoUpdateForm;
import br.edu.ifs.academico.service.exceptions.DataIntegrityException;
import br.edu.ifs.academico.service.exceptions.ObjectNotFoundException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DataIntegrityViolationException;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;
import java.util.NoSuchElementException;
import java.util.Optional;

@Service
public class HistoricoService {

    @Autowired
    HistoricoRepository historicoRepository;
    @Autowired
    HorarioRepository horarioRepository;

    public HistoricoDto findById(long idHistorio) {
        try {
            HistoricoModel historicoModel = historicoRepository.findById(idHistorio).get();
            return convertHistoricoModelToHistoricoDto(historicoModel);
        } catch (NoSuchElementException e) {
            throw new ObjectNotFoundException("Objeto não encontrado! ID : " + idHistorio + ", Tipo: " + HistoricoModel.class.getName());
        }
    }

    public List<HistoricoDto> findAll(){
        List<HistoricoModel> historicoList = historicoRepository.findAll();
        return convertListToDto(historicoList);
    }

    public HistoricoDto insert(HistoricoForm historicoForm) {
        try {
            HistoricoModel historicoNovo = convertHistoricoFormToHistoricoModel(historicoForm);
            historicoRepository.save(historicoNovo);
            return convertHistoricoModelToHistoricoDto(historicoNovo);
        } catch (DataIntegrityViolationException e) {
            throw new DataIntegrityException("Campo(s) obrigatório(s) do horario não foi(foram) preenchido(s).");
        }
    }

    public HistoricoDto update(HistoricoUpdateForm historicoUpdateForm, long idHistorico) {
        try {
            Optional<HistoricoModel> historicoExistente = historicoRepository.findById(idHistorico);
            if (historicoExistente.isPresent()) {
                HistoricoModel historicoAtualizado = historicoExistente.get();
                HorarioModel horarioAtualizado = new HorarioModel();
                horarioAtualizado.setIdHorario(historicoUpdateForm.getIdHorario());
                historicoAtualizado.setHorarioModel(horarioAtualizado);
                historicoRepository.save(historicoAtualizado);
                return convertHistoricoModelToHistoricoDto(historicoAtualizado);
            }else{
                throw new DataIntegrityException("O ID do historico não existe na base de dados!");
            }
        } catch (DataIntegrityViolationException e) {
            throw new DataIntegrityException("Campo(s) obrigatório(s) do Historico não foi(foram) preenchido(s).");
        }
    }

    public void delete(long idHistorico) {
        try {
            if (historicoRepository.existsById(idHistorico)) {
                historicoRepository.deleteById(idHistorico);
            }
        } catch (DataIntegrityViolationException e) {
            throw new DataIntegrityException("Não é possível excluir um Historico!");
        }
    }

    private HistoricoModel convertHistoricoFormToHistoricoModel(HistoricoForm historicoForm) {
        HistoricoModel historicoModel = new HistoricoModel();
        historicoModel.setDataHora(historicoForm.getDataHora());
        HorarioModel horarioModel = new HorarioModel();
        horarioModel.setIdHorario(historicoForm.getIdHorario());
        historicoModel.setHorarioModel(horarioModel);
        return historicoModel;
    }

    private HistoricoDto convertHistoricoModelToHistoricoDto(HistoricoModel historicoModel) {
        HistoricoDto historicoDto = new HistoricoDto();
        historicoDto.setIdHistorico(historicoModel.getIdHistorico());
        historicoDto.setDatahora(historicoModel.getDataHora());
        Optional<HorarioModel> optionalHorarioModel = horarioRepository.findById(historicoModel.getHorarioModel().getIdHorario());
        historicoDto.setIdHorario(optionalHorarioModel.get().getIdHorario());
        return historicoDto;
    }

    private List<HistoricoDto> convertListToDto(List<HistoricoModel> list){
        List<HistoricoDto> historicoDtoList = new ArrayList<>();
        for (HistoricoModel historicoModel : list) {
            HistoricoDto historicoDto = this.convertHistoricoModelToHistoricoDto(historicoModel);
            historicoDtoList.add(historicoDto);
        }
        return historicoDtoList;
    }
}
