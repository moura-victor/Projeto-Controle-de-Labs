package br.edu.ifs.academico.service;

import br.edu.ifs.academico.model.UsuarioModel;
import br.edu.ifs.academico.repository.UsuarioRepository;
import br.edu.ifs.academico.rest.dto.UsuarioDto;
import br.edu.ifs.academico.rest.form.UsuarioForm;
import br.edu.ifs.academico.rest.form.UsuarioUpdateForm;
import br.edu.ifs.academico.service.exceptions.DataIntegrityException;
import br.edu.ifs.academico.service.exceptions.ObjectNotFoundException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DataIntegrityViolationException;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;
import java.util.NoSuchElementException;
import java.util.Optional;

@Service
public class UsuarioService {

    @Autowired
    UsuarioRepository usuarioRepository;

    public UsuarioDto findById(long idUsuario) {
        try {
            UsuarioModel usuarioModel = usuarioRepository.findById(idUsuario).get();
            return convertUsuarioModelToUsuarioDto(usuarioModel);
        } catch (NoSuchElementException e) {
            throw new ObjectNotFoundException("Objeto não encontrado! Matrícula: " + idUsuario + ", Tipo: " + UsuarioModel.class.getName());
        }
    }

    public List<UsuarioDto> findAll(){
        List<UsuarioModel> usuarioList = usuarioRepository.findAll();
        return convertListToDto(usuarioList);
    }

    public UsuarioDto insert(UsuarioForm usuarioForm) {
        try {
            UsuarioModel usuarioNovo = convertUsuarioFormToUsuarioModel(usuarioForm);
            Optional<UsuarioModel> byMatricula = usuarioRepository.findByMatricula(usuarioNovo.getMatricula());
            if(byMatricula.isPresent()) {
                throw new IllegalStateException("Matrícula já registrada.");
            }
            usuarioNovo.setAtivo(true);
            usuarioNovo = usuarioRepository.save(usuarioNovo);
            return convertUsuarioModelToUsuarioDto(usuarioNovo);
        } catch (DataIntegrityViolationException e) {
            throw new DataIntegrityException("Campo(s) obrigatório(s) do Usuário não foi(foram) preenchido(s).");
        }
    }

    public UsuarioDto update(UsuarioUpdateForm usuarioUpdateForm, long idUsuario) {
        try {
            Optional<UsuarioModel> usuarioExistente = usuarioRepository.findById(idUsuario);
            if (usuarioExistente.isPresent()) {
                UsuarioModel usuarioAtualizado = usuarioExistente.get();
                usuarioAtualizado.setMatricula(usuarioUpdateForm.getMatricula());
                usuarioAtualizado.setSenha(usuarioUpdateForm.getSenha());
                usuarioAtualizado.setAtivo(usuarioUpdateForm.isAtivo());
                usuarioRepository.save(usuarioAtualizado);
                return convertUsuarioModelToUsuarioDto(usuarioAtualizado);
            }else{
                throw new DataIntegrityException("A Matrícula do Aluno não existe na base de dados!");
            }
        } catch (DataIntegrityViolationException e) {
            throw new DataIntegrityException("Campo(s) obrigatório(s) do Aluno não foi(foram) preenchido(s).");
        }
    }

    public void delete(long idUsuario) {
        Optional<UsuarioModel> usuarioExistente = usuarioRepository.findById(idUsuario);
        try {
            if (usuarioExistente.isPresent()) {
                usuarioRepository.deleteById(idUsuario);
            }
        } catch (DataIntegrityViolationException e) {
            throw new DataIntegrityException("Não é possível excluir um Usuário!");
        }
    }

    private UsuarioModel convertUsuarioFormToUsuarioModel(UsuarioForm usuarioForm) {
        UsuarioModel usuarioModel = new UsuarioModel();
        usuarioModel.setMatricula(usuarioForm.getMatricula());
        usuarioModel.setSenha(usuarioForm.getSenha());
        usuarioModel.setAdmin(usuarioForm.isAdmin());
        return usuarioModel;
    }

    private UsuarioDto convertUsuarioModelToUsuarioDto(UsuarioModel usuarioModel) {
        UsuarioDto usuarioDto = new UsuarioDto();
        usuarioDto.setMatricula(usuarioModel.getMatricula());
        usuarioDto.setIdUsuario(usuarioModel.getIdUsuario());
        usuarioDto.setAtivo(usuarioModel.isAtivo()); //isAtivo daria no mesmo que getAtivo?
        usuarioDto.setAdmin(usuarioModel.isAdmin());
        return usuarioDto;
    }

    private List<UsuarioDto> convertListToDto(List<UsuarioModel> list){
        List<UsuarioDto> usuarioDtoList = new ArrayList<>();
        for (UsuarioModel usuarioModel : list) {
            UsuarioDto usuarioDto = this.convertUsuarioModelToUsuarioDto(usuarioModel);
            usuarioDtoList.add(usuarioDto);
        }
        return usuarioDtoList;
    }
}