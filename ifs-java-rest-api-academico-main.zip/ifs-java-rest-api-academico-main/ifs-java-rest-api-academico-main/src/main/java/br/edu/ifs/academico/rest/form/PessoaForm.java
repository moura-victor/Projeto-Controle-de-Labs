package br.edu.ifs.academico.rest.form;

import com.fasterxml.jackson.annotation.JsonFormat;
import lombok.Data;

import org.hibernate.validator.constraints.br.CPF;
import javax.validation.constraints.*;
import java.time.LocalDate;

@Data
public class PessoaForm {

    @NotEmpty
    @NotBlank(message = "O nome não pode estar em branco")
    @Size(max = 128)
    private String nome;

    @NotNull
    @NotBlank
    @CPF(message = "O número informado de CPF é inválido")
    @Size(min = 11, max= 11)
    private String cpf;

    @NotNull(message = "Data de nascimento não pode ser nula.")
    @Past(message = "A data de nascimento informada deve ser anterior ao dia atual.")
    @JsonFormat(pattern = "dd/MM/yyyy")
    private LocalDate dataNascimento;

    @Size(max = 64)
    private String sexo;
}
