package br.edu.ifs.academico.repository;

import br.edu.ifs.academico.model.PessoaModel;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;
import java.util.Optional;

public interface PessoaRepository extends JpaRepository<PessoaModel, Long> {

    List<PessoaModel> findByNomeContaining(String nome);

    List<PessoaModel> findByOrderByNomeAsc();

    Optional<PessoaModel> findByIdPessoa(Long IdPessoa);

    Optional<PessoaModel> findByCpf(String cpf);


}
