package br.edu.ifs.academico.rest.dto;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;


@Data
@AllArgsConstructor
@NoArgsConstructor
public class UsuarioDto {
    private Long idUsuario;
    private String matricula;
    private boolean ativo;
    private boolean admin;


}
